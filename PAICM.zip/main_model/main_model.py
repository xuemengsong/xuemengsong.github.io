import numpy as np
import tensorflow as tf
import os, time, pickle
from datetime import datetime
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

batch_size = 64
n_in = 362
n_out = 2
n_hidden = 256
style_num = 90
outfit_num = 49716
display_step = 1
momentum = 0.8
training_epochs = 100

class MODEL(object):
    def __init__(self, learning_rate=0.01, momentum=0.8, mu=0.0001, lam=0.1, ups=0.1):

        self.learning_rate = learning_rate
        self.momentum = momentum
        self.mu = mu
        self.lam = lam
        self.ups = ups

        self.ti = tf.placeholder(tf.float32, [batch_size, n_in])
        self.bj = tf.placeholder(tf.float32, [batch_size, n_in])
        self.bk = tf.placeholder(tf.float32, [batch_size, n_in])

        initializer1 = tf.random_normal_initializer(mean=0, stddev=0.01)
        initializer2 = tf.random_uniform_initializer(0, 0.1)

        self.Weight1 = tf.get_variable(name='weight1',shape=[n_in, n_hidden],dtype=tf.float32,
                                         initializer=initializer1)
        self.bias1 = tf.get_variable(name='bias1', shape=[n_hidden],dtype=tf.float32,
                                         initializer=initializer1)
        self.Weight2 = tf.get_variable(name='weight2',shape=[n_in, n_hidden],dtype=tf.float32,
                                         initializer=initializer1)
        self.bias2 = tf.get_variable(name='bias2', shape=[n_hidden],dtype=tf.float32,
                                         initializer=initializer1)

        self.P = tf.get_variable(name='P',shape=[2*n_in, style_num],dtype=tf.float32,
                                         initializer=initializer2)
        self.H1 = tf.get_variable(name='H1',shape=[style_num, outfit_num],dtype=tf.float32,
                                         initializer=initializer2)
        self.U = tf.get_variable(name='U',shape=[2*n_in, style_num],dtype=tf.float32,
                                         initializer=initializer2)
        self.H2 = tf.get_variable(name='H2',shape=[style_num, outfit_num],dtype=tf.float32,
                                         initializer=initializer2)


        self.modeling()

    def modeling(self):
        self.style_ij = self.get_style(self.ti, self.bj, self.P)
        self.style_ik = self.get_style(self.ti, self.bk, self.U)

        self.s_style_ij = self.get_style_score(self.style_ij)
        self.s_style_ik = self.get_style_score(self.style_ik)

        self.ti_ = tf.nn.sigmoid(tf.matmul(self.ti, self.Weight1) + self.bias1)
        self.bj_ = tf.nn.sigmoid(tf.matmul(self.bj, self.Weight2) + self.bias2)
        self.bk_ = tf.nn.sigmoid(tf.matmul(self.bk, self.Weight2) + self.bias2)

        bj_t = tf.transpose(self.bj_)
        bk_t = tf.transpose(self.bk_)

        sij = tf.matmul(self.ti_, bj_t)
        sik = tf.matmul(self.ti_, bk_t)

        self.sij = tf.diag_part(sij)
        self.sik = tf.diag_part(sik)

        self.corr, self.auc = self.get_auc()
        self.sij_k = tf.nn.sigmoid(self.sij - self.sik)
        self.s_style_ij_k = tf.nn.sigmoid(self.s_style_ij - self.s_style_ik)
        self.cost1 = - tf.reduce_mean(tf.log(self.sij_k))
        self.cost2 = - tf.reduce_mean(tf.log(self.s_style_ij_k))

        self.cost_norm = self.mu * (tf.reduce_mean(tf.square(self.Weight1)) +
                                    tf.reduce_mean(tf.square(self.bias1)) +
                                    tf.reduce_mean(tf.square(self.Weight2)) +
                                    tf.reduce_mean(tf.square(self.bias2)))

        clip_P = self.P.assign(tf.maximum(tf.zeros_like(self.P), self.P))
        clip_H1 = self.H1.assign(tf.maximum(tf.zeros_like(self.H1), self.H1))
        clip_U = self.U.assign(tf.maximum(tf.zeros_like(self.U), self.U))
        clip_H2 = self.H2.assign(tf.maximum(tf.zeros_like(self.H2), self.H2))
        self.clip = tf.group(clip_P, clip_H1, clip_U, clip_H2)

        PH = tf.matmul(self.P, self.H1)
        UH = tf.matmul(self.U, self.H2)

        self.cost3 = tf.reduce_sum(tf.square(A - PH))
        self.cost4 = tf.reduce_sum(tf.square(B - UH))

        self.cost = 10 * self.cost1 + self.lam * self.cost2 + self.ups * self.cost3 + self.ups * self.cost4 + self.cost_norm
        # self.cost = self.cost3 + self.cost4
        optml1 = tf.train.AdamOptimizer(learning_rate=self.learning_rate, epsilon=1e-8)
        # optml2 = tf.train.MomentumOptimizer(learning_rate=self.learning_rate, momentum=self.momentum)
        self.optm = optml1.minimize(self.cost)


    def get_style(self, t, b, weight):
        for i in range(t.shape[0]):
            tb = tf.concat([t[i], b[i]], 0)
            tb = tf.reshape(tb, [2*n_in, 1])
            style_index = tf.arg_min(tf.reduce_sum(tf.square(weight-tb), 0), 0)
            W_T = tf.transpose(weight)
            style = tf.gather(W_T, style_index)
            return style

    def get_style_score(self, style):
        style = tf.reshape(style, [2, n_in])
        t_s = tf.nn.sigmoid(tf.matmul(tf.reshape(style[0], [1, n_in]), self.Weight1) + self.bias1)
        b_s = tf.nn.sigmoid(tf.matmul(tf.reshape(style[1], [1, n_in]), self.Weight2) + self.bias2)
        b_s_T = tf.transpose(b_s)
        style_score = tf.matmul(t_s, b_s_T)
        return style_score

    def get_auc(self):
        a = tf.reshape(self.sij, shape=[batch_size, 1])
        b = tf.reshape(self.sik, shape=[batch_size, 1])
        ab = tf.concat([a, b], 1)
        corr = tf.equal(tf.arg_max(ab, 1), 0)
        auc = tf.reduce_mean(tf.cast(corr, tf.float32))
        return corr, auc


def train(model, iteration):

    print('start training')
    train_batch = int(train_set_ti.shape[0] / batch_size)
    fi = open('main_model_mf.txt', 'a')
    fi.write('******lr: %.10f, mu: %f, n_hidden: %i, style_num: %i, cost_lam: %f***80***\n' % (learning_rate, mu, n_hidden, style_num, lamb))
    fi.flush()
    opt_test = 0.0
    opt_epoch = 0.0
    min_pre = 0.7
    for epoch in range(training_epochs):

        avg_cost = 0.
        avg_cost1 = 0.
        avg_cost2 = 0.
        avg_cost3 = 0.
        avg_cost4 = 0.
        avg_auc = 0.
        start_time = time.time()
        for i in range(train_batch):

            train_ti = train_set_ti[i*batch_size: (i+1)*batch_size]
            train_bj = train_set_bj[i * batch_size: (i + 1) * batch_size]
            train_bk = train_set_bk[i * batch_size: (i + 1) * batch_size]
            auc_, _, loss_out, cost1, cost2, cost3, cost4 = sess.run([model.auc, model.optm, model.cost, model.cost1, model.cost2, model.cost3, model.cost4],
                                         feed_dict={model.ti: train_ti, model.bj: train_bj, model.bk: train_bk})

            sess.run(model.clip)
            avg_cost += loss_out
            avg_cost1 += cost1
            avg_cost2 += cost2
            avg_cost3 += cost3
            avg_cost4 += cost4
            avg_auc += auc_

        if epoch % display_step == 0:
            avg_cost = avg_cost / train_batch
            avg_cost1 = avg_cost1 / train_batch
            avg_cost2 = avg_cost2 / train_batch
            avg_cost3 = avg_cost3 / train_batch
            avg_cost4 = avg_cost4 / train_batch
            avg_auc = avg_auc / train_batch

            test_auc = 0.
            test_corr = []
            test_batch = int(test_set_ti.shape[0] / batch_size)
            for i in range(test_batch):
                test_ti = test_set_ti[i*batch_size: (i+1)*batch_size]
                test_bj = test_set_bj[i * batch_size: (i + 1) * batch_size]
                test_bk = test_set_bk[i * batch_size: (i + 1) * batch_size]
                auc_, corr_= sess.run([model.auc, model.corr], feed_dict={model.ti: test_ti, model.bj: test_bj, model.bk: test_bk})
                test_auc += auc_
                test_corr.append(corr_)

            test_auc = test_auc / test_batch
            if test_auc > opt_test:
                opt_test = test_auc
                opt_epoch = epoch
                P = sess.run(model.P)
                opt_corr = test_corr
            duration = time.time() - start_time

            print('train epoch %i, cost: %.4f, train auc: %.4f' % (epoch, avg_cost, avg_auc))
            print('cost1: %f, cost2: %f, cost3: %f, cost4: %f' % (avg_cost1, avg_cost2, avg_cost3, avg_cost4))
            print('test auc: %.4f' % (test_auc))
            print('%s: step %d, duration = %.3f' % (datetime.now(), epoch, duration))
            fi.write('train epoch %i, cost\t%.4f\t, train auc\t%.4f' % (epoch, avg_cost, avg_auc))
            fi.write('test auc\t%.4f\n' % (test_auc))
            # fi.write('cost1: %f, cost2: %f, cost3: %f, cost4: %f\n' % (avg_cost1, avg_cost2, avg_cost3, avg_cost4))
            fi.flush()
            if test_auc > min_pre:
                model_dir = 'main_model_iteration' + str(iteration)
                try:
                    os.mkdir(model_dir)
                except:
                    pass
                min_pre = test_auc
                saver.save(sess, save_path=model_dir+'\epoch'+str(epoch)+'auc'+str(int(test_auc*10000)))
                print('save model in epoch %d' % epoch)
    P = np.array(P)
    print(P.shape)
    np.savetxt('NMF_P_'+str(iteration)+'.txt', P, fmt='%f')

    opt_corr = np.array(opt_corr)
    print(opt_corr.shape)
    opt_corr = opt_corr.reshape((97*64))
    np.savetxt('main_model_corr_' + str(iteration) + '.txt', opt_corr, fmt='%f')
    print('opt_test: %.4f, opt_epoch: %i\n' % (opt_test, opt_epoch))
    fi.write('opt_test: %.4f, opt_epoch: %i\n' % (opt_test, opt_epoch))
    fi.close()

def load_model():
    with tf.Session() as sess:
        saver = tf.train.import_meta_graph('./main_model_iteration5/epoch188auc7130.meta')
        saver.restore(sess, tf.train.latest_checkpoint('main_model_iteration5'))

        test_cloth = np.loadtxt('./NMF_original_pair.txt', dtype='float32')
        test_new_cloth = np.loadtxt('./NMF_manipulated_pair.txt', dtype='float32')
        test_cloth = np.array(test_cloth)
        test_new_cloth = np.array(test_new_cloth)
        count_diff = 0
        for i in range(test_cloth.shape[0]):
            for j in range(test_cloth.shape[1]):
                if test_cloth[i][j] != test_new_cloth[i][j]:
                    count_diff += 1
        print(count_diff)
        def get_ijk(a):
            i = []
            j = []
            k = []
            for n in range(a.shape[0]):
                i.append(a[n][:362])
                j.append(a[n][362:])
                k.append(a[n][362:])
            i = np.array(i)
            j = np.array(j)
            k = np.array(k)
            return i, j, k
        test_i, test_j, test_k = get_ijk(test_cloth)
        test_batch = int(test_cloth.shape[0] / batch_size)
        test_score = []
        for i in range(test_batch):
            test_ti = test_i[i * batch_size: (i + 1) * batch_size]
            test_bj = test_j[i * batch_size: (i + 1) * batch_size]
            test_bk = test_k[i * batch_size: (i + 1) * batch_size]
            sij_ = sess.run(model.sij, feed_dict={model.ti: test_ti, model.bj: test_bj, model.bk: test_bk})
            test_score.append(sij_)

        test_new_i, test_new_j, test_new_k = get_ijk(test_new_cloth)
        test_new_batch = int(test_new_cloth.shape[0] / batch_size)
        test_new_score = []
        for i in range(test_new_batch):
            test_ti = test_new_i[i * batch_size: (i + 1) * batch_size]
            test_bj = test_new_j[i * batch_size: (i + 1) * batch_size]
            test_bk = test_new_k[i * batch_size: (i + 1) * batch_size]
            sij_new_ = sess.run(model.sij, feed_dict={model.ti: test_ti, model.bj: test_bj, model.bk: test_bk})
            test_new_score.append(sij_new_)
        test_score = np.array(test_score)
        test_new_score = np.array(test_new_score)
        test_score = test_score.reshape((test_batch * batch_size, 1))
        test_new_score = test_new_score.reshape((test_new_batch * batch_size, 1))
        print(test_score.shape)
        count = 0.
        for i in range(test_score.shape[0]):
            if test_new_score[i] > test_score[i]:
                count += 1
        final_score = count / test_score.shape[0]
        print(final_score)

def load_model2():

    with open('./test_set.pkl', 'rb') as f:
        test_set_ti, test_set_bj, test_set_bk = np.asarray(pickle.load(f), dtype='float32')
    with tf.Session() as sess:
        saver = tf.train.import_meta_graph('./main_model_iteration5/epoch188auc7130.meta')
        saver.restore(sess, tf.train.latest_checkpoint('main_model_iteration5'))
        test_auc = 0.
        test_i = []
        test_j = []
        test_k = []
        a = test_set_ti.shape[0]
        extral_num = batch_size - (test_set_ti.shape[0] % batch_size)
        test_set_ti = np.append(test_set_ti, test_set_ti[0:extral_num], axis=0)
        test_set_bj = np.append(test_set_bj, test_set_bj[0:extral_num], axis=0)
        test_set_bk = np.append(test_set_bk, test_set_bk[0:extral_num], axis=0)
        test_batch = int(test_set_ti.shape[0] / batch_size)

        for i in range(test_batch):
            test_ti = test_set_ti[i * batch_size: (i + 1) * batch_size]
            test_bj = test_set_bj[i * batch_size: (i + 1) * batch_size]
            test_bk = test_set_bk[i * batch_size: (i + 1) * batch_size]
            i_, j_, k_ = sess.run([model.ti_, model.bj_, model.bk_],
                                   feed_dict={model.ti: test_ti, model.bj: test_bj, model.bk: test_bk})

            test_i.append(i_)
            test_j.append(j_)
            test_k.append(k_)
        test_i = np.array(test_i)
        print(test_i.shape)
        test_j = np.array(test_j)
        test_k = np.array(test_k)
        test_i = test_i.reshape((test_batch * batch_size, 256))
        test_j = test_j.reshape((test_batch * batch_size, 256))
        test_k = test_k.reshape((test_batch * batch_size, 256))

        test_i = test_i[: a]
        test_j = test_j[: a]
        test_k = test_k[: a]
        np.savetxt('./data/test_i.txt', test_i, fmt='%f')
        np.savetxt('./data/test_j.txt', test_j, fmt='%f')
        np.savetxt('./data/test_k.txt', test_k, fmt='%f')

if __name__ == '__main__':

    print(time.strftime("%Y-%m-%d %H-%M-%S", time.localtime()))
    with open('./data_mm_id/train_set_362_norm2.pkl', 'rb') as f:
        train_set_ti,train_set_bj, train_set_bk = np.asarray(pickle.load(f), dtype='float32')
    with open('./data_mm_id/test_set_362_norm2.pkl', 'rb') as f:
        test_set_ti, test_set_bj, test_set_bk = np.asarray(pickle.load(f), dtype='float32')

    A = np.transpose(np.concatenate([train_set_ti, train_set_bj], axis=1))
    B = np.transpose(np.concatenate([train_set_ti, train_set_bk], axis=1))

    iteration = 0
    learning_rate = [0.0002]
    lambs = [0.2]
    mus = [0.01]
    for lr in learning_rate:
        for lamb_ in lambs:
            for mu_ in mus:
                iteration += 1
                learning_rate = lr
                mu = mu_
                lamb = lamb_
                ups = 0.1
                tf.reset_default_graph()
                model = MODEL(learning_rate, momentum, mu, lamb, ups)

                config = tf.ConfigProto()
                config.gpu_options.allow_growth = True
                session = tf.Session(config=config)

                sess = tf.Session()
                init = tf.global_variables_initializer()
                sess.run(init)
                saver = tf.train.Saver()
                train(model, iteration)

                # testing the effect of attribute manipulation
                # load_model()

                # get latent representation for MRR test
                # load_model2()