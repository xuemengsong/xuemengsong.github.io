import tensorflow as tf

def print_activations(t):
    print(t.op.name, '', t.get_shape().as_list())

def conv2d(name, input1, w, b, stride, padding='SAME'):

    x = input1.get_shape()[-1]
    x = tf.nn.conv2d(input1, w, strides=[1, stride, stride, 1], padding=padding, )
    x = tf.nn.bias_add(x, b)
    data_result = tf.nn.relu(x, name=name)

    return data_result

def max_pool(name, input1, k, stride):
    return tf.nn.max_pool(input1, ksize=[1, k, k, 1], strides=[1, stride, stride, 1], padding='SAME', name=name)

def fc(input1, w, b):
    return tf.nn.relu(tf.add(tf.matmul(input1, w), b))

def norm(name, input1, size1=4):
    return tf.nn.lrn(input1, size1, bias=1.0, alpha=0.001 / 9.0, beta=0.75, name=name)

class CNNConfig(object):

    img_size = 227
    l2_reg_lambda = 0.000

    def __init__(self, class_num=303, learning_rate=0.0001, dropout=0.1, momentum=0.8, step=100):
        self.learning_rate = learning_rate
        self.dropout = dropout
        self.n_output = class_num
        self.momentum = momentum
        self.step = step
        self.batch_size = 64
        self.weights = {
            'wc1': tf.Variable(tf.random_normal([11, 11, 3, 96], stddev=0.01)),
            'wc2': tf.Variable(tf.random_normal([5, 5, 96, 256], stddev=0.01)),
            'wc3': tf.Variable(tf.random_normal([3, 3, 256, 384], stddev=0.01)),
            'wc4': tf.Variable(tf.random_normal([3, 3, 384, 384], stddev=0.01)),
            'wc5': tf.Variable(tf.random_normal([3, 3, 384, 256], stddev=0.01)),
            'wd1': tf.Variable(tf.random_normal([4096, 4096], stddev=0.01)),
            'wd2': tf.Variable(tf.random_normal([4096, 1024], stddev=0.01)),
            'wd3': tf.Variable(tf.random_normal([1024, self.n_output], stddev=0.01))
        }

        self.biases = {
            'bc1': tf.Variable(tf.random_normal([96], stddev=0.01)),
            'bc2': tf.Variable(tf.random_normal([256], stddev=0.01)),
            'bc3': tf.Variable(tf.random_normal([384], stddev=0.01)),
            'bc4': tf.Variable(tf.random_normal([384], stddev=0.01)),
            'bc5': tf.Variable(tf.random_normal([256], stddev=0.01)),
            'bd1': tf.Variable(tf.random_normal([4096], stddev=0.01)),
            'bd2': tf.Variable(tf.random_normal([1024], stddev=0.01)),
            'bd3': tf.Variable(tf.random_normal([self.n_output], stddev=0.01))
        }


class CNN(object):

    def __init__(self, config):
        self.config = config
        self.input_x = tf.placeholder(tf.float32,
                                      [None, config.img_size, config.img_size, 3])
        self.input_y = tf.placeholder(tf.float32, [None, config.n_output])
        self.keep_prob = tf.placeholder(tf.float32)
        self.scores = None
        self.loss = None
        self.accuracy = None
        self.optm = None
        self.logits = None
        self.alex()

    def alex(self):

        _input_r = tf.reshape(self.input_x, [-1, self.config.img_size, self.config.img_size, 3])

        with tf.name_scope('conv1'):
            with tf.device('/cpu:0'):
                _conv1 = conv2d('conv1', _input_r, self.config.weights['wc1'], self.config.biases['bc1'], stride=4)
                print_activations(_conv1)

        with tf.name_scope('pool1'):
            _pool1 = max_pool('pool1', _conv1, k=3, stride=2)
            print_activations(_pool1)

        with tf.name_scope('conv2'):
            _conv2 = conv2d('conv2', _pool1, self.config.weights['wc2'], self.config.biases['bc2'], stride=2)
            print_activations(_conv2)

        with tf.name_scope('pool2'):
            _pool2 = max_pool('pool2', _conv2, k=3, stride=2)
            print_activations(_pool2)

        with tf.name_scope('norm2'):
            norm2 = norm('norm2', _pool2, size1=5)

        with tf.name_scope('conv3'):
            _conv3 = conv2d('conv3', norm2, self.config.weights['wc3'], self.config.biases['bc3'], stride=1)
            print_activations(_conv3)

        with tf.name_scope('conv4'):
            _conv4 = conv2d('conv4', _conv3, self.config.weights['wc4'], self.config.biases['bc4'], stride=1)
            print_activations(_conv4)

        with tf.name_scope('conv5'):
            _conv5 = conv2d('conv5', _conv4, self.config.weights['wc5'], self.config.biases['bc5'], stride=1)
            print_activations(_conv5)

        with tf.name_scope('pool3'):
            _pool3 = max_pool('pool3', _conv5, k=3, stride=2)
            print_activations(_pool3)

        with tf.name_scope('fc1'):
            fc1 = tf.reshape(_pool3, [-1, self.config.weights['wd1'].get_shape().as_list()[0]])
            _fc1 = fc(fc1, self.config.weights['wd1'], self.config.biases['bd1'])

            _fc1_drop = tf.nn.dropout(_fc1, self.keep_prob)
            print_activations(_fc1_drop)

        with tf.name_scope('fc2'):
            _fc2 = fc(_fc1_drop, self.config.weights['wd2'], self.config.biases['bd2'])
            _fc2_drop = tf.nn.dropout(_fc2, self.keep_prob)
            print_activations(_fc2_drop)

        with tf.name_scope('outputs'):
            self.logits = tf.add(tf.matmul(_fc2_drop, self.config.weights['wd3']), self.config.biases['bd3'])
            self.scores = tf.sigmoid(self.logits, name='scores')
            print_activations(self.logits)

        with tf.name_scope("optimize"):
            self.learning_rate_ = tf.train.exponential_decay(self.config.learning_rate, self.config.step, 50, 0.95,staircase=False)
            cross_entropy = tf.nn.softmax_cross_entropy_with_logits(logits=self.logits, labels=self.input_y)
            self.loss = tf.reduce_mean(cross_entropy)

            optm1 = tf.train.AdamOptimizer(learning_rate=self.learning_rate_, epsilon=1e-8)
            # optm1 = tf.train.MomentumOptimizer(learning_rate=self.config.learning_rate, momentum=self.config.momentum)
            self.optm = optm1.minimize(self.loss)


        with tf.name_scope('accuracy'):
            corr = tf.equal(tf.argmax(self.logits, 1),
                            tf.argmax(self.input_y, 1))
            self.accuracy = tf.reduce_mean(tf.cast(corr, tf.float32))

