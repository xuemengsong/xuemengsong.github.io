import tensorflow as tf
import numpy as np
import os, io
from skimage import io,transform
from datetime import datetime
import time
from keras_preprocessing.image import ImageDataGenerator, img_to_array
from PIL import Image
from Alex import CNNConfig
from Alex import CNN
import logging
from random import randint
from sklearn import metrics

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
session = tf.Session(config=config)

data_dir = './data/dress/'
# dir of id and label of training set and test set
train_dir = './data_div/dress_train/'
test_dir = './data_div/dress_test/'
learning_rate = [0.0000005]
dropout = [0.8]
momentum = [0.8]

# attribute class
class_ = '17'
n_output_list = [14, 9, 77, 7, 8, 26, 21, 7, 15, 39, 12, 10, 9, 8, 11, 12, 7, 11]
n_output = n_output_list[int(class_) - 1]

training_epochs = 90
batch_size = 64
display_step = 1
aug_num = 10    # data augmentation
max_img_num = 1000
label_threshold = 0.50

try:
    os.mkdir('./dress_model'+class_+'/')
except:
    pass
model_dir = './dress_model'+class_+'/'

img_size = 227
x_shape = [img_size, img_size, 3]
constant_arr = np.ones(x_shape, dtype='float32') * 255


logger = logging.getLogger(__name__)
logger.setLevel(level=logging.INFO)
handler = logging.FileHandler("log.txt")
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

console = logging.StreamHandler()
console.setLevel(logging.INFO)

logger.addHandler(handler)
logger.addHandler(console)

def liner_norm(x):

    for i1 in range(x.shape[0]):
        max_ = max(x[i1])
        min_ = min(x[i1])
        x[i1] = (x[i1] - min_) * 1.0 / (max_ - min_ + 0.001)
    return x

def get_acc(predicts, labels, i1):

    label = labels[i1 * batch_size: (i1 + 1) * batch_size]
    predicts_cast = np.zeros((batch_size, n_output))
    predicts = liner_norm(predicts)
    for j in range(predicts.shape[0]):
        count = 0
        for k in range(predicts.shape[1]):
            if predicts[j][k] > label_threshold:
                predicts_cast[j][k] = 1.
                count += 1
            else:
                predicts_cast[j][k] = -1.
                # if j % 50 == 0:
                # print(count)
    acc = np.mean(np.equal(predicts_cast, label))
    tp = 0.
    fp = 0.
    fn = 0.
    tn = 0.
    precision = 0.
    recall = 0
    for j in range(predicts.shape[0]):
        for k in range(predicts.shape[1]):
            if label[j][k] == 1. and predicts_cast[j][k] == 1.:
                tp += 1.
            if label[j][k] == -1. and predicts_cast[j][k] == 1.:
                fp += 1.
            if label[j][k] == 1. and predicts_cast[j][k] == -1.:
                fn += 1.
            if label[j][k] == -1. and predicts_cast[j][k] == -1.:
                tn += 1.
        if tp + fp == 0.:
            precision = 0.
        else:
            precision += tp / (tp + fp)
        recall += tp / (tp + fn)
    avg_precision = precision / batch_size
    avg_recall = recall / batch_size
    return [acc, avg_precision, avg_recall]

def get_auc(scores, labels, i1):

    label = labels[i1 * batch_size: (i1 + 1) * batch_size]
    avg_auc = 0.0
    for i in range(scores.shape[0]):
        auc = metrics.roc_auc_score(label[i], scores[i])
        avg_auc += auc
    avg_auc = avg_auc / scores.shape[0]
    return avg_auc

def get_class_len_list(id_path):

    id_files = os.listdir(id_path)
    file_len_list = []
    for id_file in id_files:
        count = len(open(id_path + id_file, 'rU').readlines())
        file_len_list.append(count)
    print(file_len_list)
    return file_len_list

def get_gen_img(x):

    x = x.reshape((1,) + x.shape)
    data_gen = ImageDataGenerator(
        rotation_range=2,
        width_shift_range=0.1,
        height_shift_range=0.1,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest')

    gen = data_gen.flow(x, batch_size=1)[0]
    return gen

def data_augmentation(id_path, label_path):
    class_len_list = get_class_len_list(id_path)
    # max_num = max(class_len_list)
    train_img_total = []
    label_total1 = []

    id_files = os.listdir(id_path)
    for index in range(len(id_files)):
        train_id_total = np.array(np.loadtxt(id_path + id_files[index], dtype=str))
        train_label_total = np.loadtxt(label_path + id_files[index], dtype=float)

        train_img_single = []
        train_label_single = []
        try:
            for ii in range(len(train_id_total)):
                train_img_raw_data = Image.open(data_dir + train_id_total[ii] + '/shop_02.jpg')
                train_img_data = train_img_raw_data.resize((img_size, img_size), Image.ANTIALIAS)
                train_img = np.array(train_img_data, dtype='float32')
                train_img.resize([img_size, img_size, 3])
                try:
                    if len(train_img.shape) != 3:
                        continue
                except:
                    pass
                train_label_single.append(train_label_total[ii])
                train_img = train_img / constant_arr
                train_img_single.append(train_img)
        except:
            pass

        aug_img = []
        aug_label = []
        try:
            len_ = train_id_total.shape[0]
        except:
            len_ = 0
        if len_ > max_img_num:
            train_img_single, train_label_single = random_choice(train_img_single, train_label_single, size1=max_img_num)
            len_ = max_img_num

        iteration_size = min(max_img_num, len_ * aug_num) - len_
        for step in range(iteration_size):
            id_random = randint(0, len_ - 1)
            img_ = train_img_single[id_random]
            if len(img_.shape) != 3:
                continue
            img_gen = get_gen_img(img_)[0]
            img_gen = np.array(img_gen)
            img_gen.resize([img_size, img_size, 3])
            aug_img.append(img_gen)
            label = train_label_single[id_random]
            aug_label.append(label)
        train_img_total.extend(aug_img)
        train_img_total.extend(train_img_single)
        label_total1.extend(aug_label)
        label_total1.extend(train_label_single)

    train_img_total = np.asarray(train_img_total)
    label_total1 = np.asarray(label_total1)
    len_img = len(train_img_total)
    len_label = len(label_total1)
    if len_img != len_label:
        print('data augmentation error')
    print(len_img)
    return len_img, train_img_total, label_total1

def random_choice(input1, input2, size1):
    random_index = np.random.choice(len(input1), size=size1, replace=False)
    ans1 = []
    ans2 = []
    for t in random_index:
        ans1.append(input1[t])
        ans2.append(input2[t])
    return ans1, ans2

def feed_data(x_batch, y_batch, keep_prob):
    feed_dict1 = {
        model.input_x: x_batch,
        model.input_y: y_batch,
        model.keep_prob: keep_prob
    }
    return feed_dict1

def train():

    min_auc = 0.8
    fi = open(class_+'class_dress.txt', 'a')
    fi.write('lr: %.10f, dr:%f, momentum: %f, aug_num: %i\n' % (learning_rate_, dropout_, momentum_, aug_num))
    fi.flush()
    opt_test = 0.0
    for epoch in range(training_epochs):
        avg_cost = 0.
        avg_acc = 0.
        avg_auc = 0.
        start_time = time.time()
        loss_out = 0.
        for i in range(int(train_batch)):
            batch_xs = img_total[i * batch_size: (i + 1) * batch_size]
            batch_ys = label_total[i * batch_size: (i + 1) * batch_size]
            feed_dict = feed_data(batch_xs, batch_ys, config.dropout)
            accuracy_, scores_,  _, loss_out = sess.run(
                [model.accuracy, model.scores, model.optm, model.loss], feed_dict=feed_dict)
            avg_cost += loss_out
            avg_acc += accuracy_
            avg_auc += get_auc(scores_, label_total, i)

        if epoch % display_step == 0:
            avg_cost = avg_cost / train_batch
            avg_acc = avg_acc / train_batch
            avg_auc = avg_auc / train_batch

            test_acc = 0.
            test_auc = 0.
            for i in range(int(test_batch)):
                images_test = test_x[i * batch_size: (i + 1) * batch_size]
                labels_test = test_y[i * batch_size: (i + 1) * batch_size]
                feed_dict = feed_data(images_test, labels_test, config.dropout)
                accuracy_, scores_ = sess.run([model.accuracy, model.scores], feed_dict=feed_dict)
                test_acc += accuracy_
                test_auc += get_auc(scores_, test_y, i)

            test_acc = test_acc / test_batch
            test_auc = test_auc / test_batch

            if test_auc > opt_test:
                opt_test = test_auc
                opt_epoch = epoch

            logger.info('train epoch %i, cost: %.4f, acc: %.4f, auc: %.4f' % (
                epoch, avg_cost, avg_acc, avg_auc))
            logger.info('test acc: %.4f, auc: %.4f' % (test_acc, test_auc))
            fi.write('train epoch %i, cost: %.4f, acc: %.4f, auc: %.4f' % (
                epoch, avg_cost, avg_acc, avg_auc))
            fi.flush()
            fi.write('test acc: %.4f, auc: %.4f\n' % (test_acc, test_auc))
            fi.flush()

            if epoch > 3:
                if test_auc > min_auc:
                    min_auc = test_auc
                    saver.save(sess, save_path=model_dir+'dress'+class_+'epoch'+str(epoch))
                    print('save model in step %d' % epoch)
                    logger.info('save model in step %d' % epoch)

        duration = time.time() - start_time
        logger.info('%s: step %d, duration = %.3f' % (datetime.now(), epoch, duration))
    fi.write('opt_test: %.4f, opt_epoch: %i\n' % (opt_test, opt_epoch))
    fi.flush()
    fi.close()

def load_model():
    with tf.Session() as sess:
        saver = tf.train.import_meta_graph('./dress_model3/dress3epoch11-11.meta')
        saver.restore(sess, tf.train.latest_checkpoint('dress_model3'))

        test_acc = 0.
        test_auc = 0.
        for i in range(int(test_batch)):
            images_test = test_x[i * batch_size: (i + 1) * batch_size]
            labels_test = test_y[i * batch_size: (i + 1) * batch_size]
            feed_dict = feed_data(images_test, labels_test, config.dropout)
            accuracy_, scores_ = sess.run([model.accuracy, model.scores], feed_dict=feed_dict)
            test_acc += accuracy_
            test_auc += get_auc(scores_, test_y, i)

        test_acc = test_acc / test_batch
        test_auc = test_auc / test_batch
        logger.info('test acc: %.4f, auc: %.4f' % (test_acc, test_auc))

def tanh_logits(x):
    for i in range(x.shape[0]):
        x[i] = np.tanh(x[i]*10)
    return x

def softmax(a):
    for i in range(a.shape[0]):
        a[i] = np.exp(a[i])/ np.sum(np.exp(a[i]))
    return a

if __name__ == '__main__':

    train_id_path = train_dir + '/id/' + class_ + '/'
    train_label_path = train_dir + '/label/' + class_ + '/'
    test_id_path = test_dir + '/id/' + class_ + '/'
    test_label_path = test_dir + '/label/' + class_ + '/'


    size, img_total, label_total = data_augmentation(train_id_path, train_label_path)
    permutation_order = np.random.permutation(img_total.shape[0])
    img_total = img_total[permutation_order]
    label_total = label_total[permutation_order]
    train_batch = size / batch_size

    test_size, test_x, test_y = data_augmentation(test_id_path, test_label_path)
    test_batch = test_size / batch_size

    for learning_rate_ in learning_rate:
        for momentum_ in momentum:
            for dropout_ in dropout:

                config = CNNConfig(class_num=n_output,
                                   learning_rate=learning_rate_,
                                   dropout=dropout_,
                                   momentum=momentum_,
                                   step=300)
                model = CNN(config)
                sess = tf.Session()
                init = tf.global_variables_initializer()
                sess.run(init)
                saver = tf.train.Saver()
                train()
                # load_model()

