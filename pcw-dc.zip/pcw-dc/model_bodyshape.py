import tensorflow as tf

def get_variable(shape, mean, stddev, name, type):
    if type=='W':
        var = tf.get_variable(name=name, shape=shape, dtype=tf.float32,
                               initializer=tf.truncated_normal_initializer(mean=mean,stddev=stddev))
        tf.add_to_collection('losses', tf.contrib.layers.l2_regularizer(0.005)(var))
        return var
    elif type=='b':
        return tf.get_variable(name=name, shape=shape, dtype=tf.float32,
                               initializer=tf.zeros_initializer())

class body_shape:
    def __init__(self):
        self.batch_size = 32
        self.feature_dim = 4096
        self.text_dim = 520 + 9
        self.class_num = 5
        self.hidden1 = 256
        category_list = ['outer', 'top', 'bottom', 'suit']

    def regression(self, image_feed, text_feed):
        # image_feed = tf.nn.l2_normalize(image_feed, dim=1)

        img_W = get_variable(shape=[self.feature_dim, self.hidden1], mean=0, stddev=0.01, name='img_W', type='W')
        img_b = get_variable(shape=[self.hidden1], mean=0, stddev=0.01, name='img_b', type='b')

        text_W = get_variable(shape=[self.text_dim, self.hidden1], mean=0, stddev=0.01, name='text_W', type='W')
        text_b = get_variable(shape=[self.hidden1], mean=0, stddev=0.01, name='text_b', type='b')

        img = tf.tanh(tf.matmul(image_feed, img_W) + img_b)
        text = tf.tanh(tf.matmul(text_feed, text_W) + text_b)

        self.feature = tf.concat((img, text), axis=1)

        pred_W = get_variable(shape=[2 * self.hidden1, self.class_num], mean=0, stddev=0.01, name='pred_W', type='W')
        pred_b = get_variable(shape=[self.class_num], mean=0, stddev=0.01, name='pred_b', type='b')
        self.y_pred = tf.sigmoid(tf.matmul(self.feature, pred_W) + pred_b)

    def train(self):
        self.image_feed = tf.placeholder(dtype=tf.float32, shape=[None, self.feature_dim])
        self.text_feed = tf.placeholder(dtype=tf.float32, shape=[None, self.text_dim])
        self.label_feed = tf.placeholder(dtype=tf.float32, shape=[None, self.class_num])

        self.regression(self.image_feed, self.text_feed)

        accuracy = tf.equal(tf.argmax(self.label_feed, axis=1), tf.argmax(self.y_pred, axis=1))
        self.accuracy = tf.reduce_mean(tf.cast(accuracy, tf.float32))

        regular_loss = tf.add_n(tf.get_collection(key='losses'))

        model_loss = tf.reduce_mean(tf.square(self.label_feed-self.y_pred))
        self.model_loss = model_loss #+regular_loss


        self.global_step = tf.Variable(0, dtype=tf.int64, name='global_step', trainable=False)
        learning_rate = tf.train.exponential_decay(0.001, self.global_step, decay_steps=200, decay_rate=0.80, staircase=False)

        self.train_step = tf.train.AdamOptimizer(learning_rate).minimize(self.model_loss)
