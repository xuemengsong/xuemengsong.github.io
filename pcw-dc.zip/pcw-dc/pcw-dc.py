import json
import numpy as np
import copy
import shutil
import os
import tensorflow as tf

import vgg16
import bsAssignment
import model_compatibility as compatibility
import model_preference as preference
import model_bodyshape as bodyshape

data_path = './files'
img_path = '../bodyFashion/'

text_dict = {}
file = open(data_path + '/item_attr.txt','r')
for idx, val in enumerate(file):
    text_dict[val.strip('\n')] = idx

with open(data_path + '/size_dict.json','r') as f:
    size_dict=json.load(f)

with open(data_path + '/bodyFashion.json','r') as f:
    data = json.load(f)
with open(data_path + '/candidate.json', 'r') as f:
    candidates = json.load(f)


class pcw_dc:
    def __init__(self):
        self.user_shape = None
        self.user_id = None
        self.scale = [0.38, 0.5, 0.52, 0.83, 0.80]  # normalization
        self.nmax = 6
        self.nmin = 2
        self.item_num = None
        self.item = None  # [outer, top, bottom, suit]
        self.outfit = []
        self.img_feature_dict = {}

        self.alpha = [0.3, 0.3, 0.4]

        self.original_score = {}
        self.pcw_score = {}

    def combine_outfit(self, item):
        outfits = []
        flag = np.nonzero(self.item_num)[0]
        if 0 in flag and 1 in flag and 2 in flag:
            for outer in item[0]:
                for top in item[1]:
                    for bottom in item[2]:
                        outfits.append('%s-%s-%s'%(outer, top, bottom))
        if 0 in flag and 3 in flag:
            for outer in item[0]:
                for suit in item[3]:
                    outfits.append('%s-%s'%(outer, suit))
        if 1 in flag and 2 in flag:
            for top in item[1]:
                for bottom in item[2]:
                    outfits.append('%s-%s'%(top, bottom))
        return outfits

    def scoring(self, item):
        f0 = 0
        ## preference
        f1 = []
        for layer in item:
            for item_id in layer:
                preference_idx = self.user_id+'-'+item_id
                if preference_idx not in self.preference_score_dict.keys():
                    # img_feature = vgg16.extract_feature(img_path + '%s.jpg' % item_id)[0]
                    if item_id not in self.img_feature_dict.keys():
                        self.img_feature_dict[item_id] = vgg16.extract_feature(img_path + '%s.jpg' % item_id)[0]

                    self.preference_score_dict[preference_idx] = \
                        self.sess_preference.run(self.preference.uij[0][0],
                                              feed_dict={self.preference.user_idx: self.preference.user_dict[self.user_id],
                                              self.preference.itemFea_pos: [self.img_feature_dict[item_id]],
                                              self.preference.itemText_pos: [self.preference.itemText[item_id]],
                                              self.preference.pos_item_idx: [self.preference.item_dict[item_id]]})
                f1.append(self.preference_score_dict[preference_idx])
        f1 = np.average(f1)

        ## bodyshape
        f2 = []
        for layer in item:
            for item_id in layer:
                bodyshape_idx = self.user_id + '-' + item_id
                if bodyshape_idx not in self.bodyshape_score_dict.keys():
                    if item_id not in self.img_feature_dict.keys():
                        self.img_feature_dict[item_id] = vgg16.extract_feature(img_path + '%s.jpg' % item_id)[0]

                    fitness = self.sess_bodyshape.run(self.bodyshape.y_pred[0],
                                                      feed_dict={self.bodyshape.image_feed: [self.img_feature_dict[item_id]],
                                                                 self.bodyshape.text_feed: [self.preference.itemText[item_id]]})
                    self.bodyshape_score_dict[bodyshape_idx] = fitness[self.user_shape]
                f2.append(self.bodyshape_score_dict[bodyshape_idx])
        f2 = np.average(f2)

        ## compatibility
        outfits = self.combine_outfit(item)
        f3 = []
        for outfit_id in outfits:
            if outfit_id not in self.outfit_score_dict.keys():
                lstm_img_feed = []
                for item_id in outfit_id.split('-'):
                    if item_id not in self.img_feature_dict.keys():
                        self.img_feature_dict[item_id] = vgg16.extract_feature(img_path+'%s.jpg'%item_id)[0]
                    lstm_img_feed.append(self.img_feature_dict[item_id])

                self.outfit_score_dict[outfit_id] = \
                    self.sess_compatibility.run(self.compatibility.score[0],
                                               feed_dict={self.compatibility.img_feature: lstm_img_feed,
                                                          self.compatibility.sequence_length: [len(lstm_img_feed)]})
            f3.append(self.outfit_score_dict[outfit_id])
        f3 = np.average(f3)
        return [f1, f2/self.scale[self.user_shape], (f3-1.8)/7.75], f0

    def add(self, cate_id):
        max_score = 0
        max_item_id = ''
        for candidate_item in candidates[str(cate_id)]:
            if candidate_item not in self.item[cate_id]:
                item = copy.deepcopy(self.item)
                item[cate_id].append(candidate_item)
                fi, norm = self.scoring(item)
                score_star = np.dot(fi, self.alpha) + norm

                if score_star > max_score:
                    max_score = score_star
                    max_item_id = candidate_item
        return max_item_id

    def delete(self, cate_id):
        max_score = 0
        max_item_id = ''
        item = copy.deepcopy(self.item)
        for candidate_item in item[cate_id]:
            item[cate_id].remove(candidate_item)
            fi, norm = self.scoring(item)
            score_star = np.dot(fi, self.alpha) + norm

            if score_star > max_score:
                max_score = score_star
                max_item_id = candidate_item
        return  max_item_id, max_score


    def PCW_creation(self):
        print(self.user_id, self.user_shape)
        print(self.item)
        original_score, _ = self.scoring(self.item)
        print(original_score)
        self.original_score[self.user_id] = original_score

        self.img_feature_dict = {}

        detect = ''
        while True:
            flag_min = np.array(self.item_num)-self.nmin
            flag_min[flag_min<0] = 0
            flag_max = self.nmax-np.array(self.item_num)
            flag_max[flag_max<0] = 0

            if flag_min.all() and flag_max.all():
                fi, norm = self.scoring(self.item)
                max_score = np.dot(fi, self.alpha) + norm
                bad_item = ''
                for cate_id in range(4):
                    delete_id, score = self.delete(cate_id)
                    print(score, max_score)
                    if score > max_score+0.01:    ##
                        bad_item = delete_id
                        if bad_item != detect:
                            self.item[cate_id].remove(delete_id)
                            self.item_num[cate_id] -= 1
                            print('delete %d: %s' % (cate_id, delete_id))
                        elif delete_id != '':
                            self.item[cate_id].remove(delete_id)
                            print('delete %d: %s' % (cate_id, delete_id))
                        detect = bad_item
                        break
                if bad_item == '':
                    break
                else:
                    continue
            else:
                for cate_id in range(4):
                    if self.item_num[cate_id]<=self.nmin:
                        add_id = self.add(cate_id)
                        if add_id != detect:
                            print('add %d: %s'% (cate_id, add_id))
                            self.item[cate_id].append(add_id)
                            self.item_num[cate_id] += 1
                        else:
                            self.item_num[cate_id] += 1
                    elif self.item_num[cate_id]>=self.nmax:
                        delete_id, _ = self.delete(cate_id)
                        self.item[cate_id].remove(delete_id)
                        self.item_num[cate_id] -= 1
                        print('delete %d: %s' % (cate_id, delete_id))
                    else:
                        continue

        pcw_score, _ = self.scoring(self.item)
        print(pcw_score)
        self.pcw_score[self.user_id] = pcw_score

        print(self.item)


    def process_data(self, user):
        self.outfit_score_dict = {}
        self.preference_score_dict = {}
        self.bodyshape_score_dict = {}
        self.img_feature_dict = {}

        self.item_num = [0,0,0,0]
        self.item = [[],[],[],[]]

        for item in user:
            item_id = item['item_id']
            item_cate = item['item_cate']
            self.img_feature_dict[item_id] = vgg16.extract_feature(img_path+'%s.jpg'%item_id)[0]
            if 'outer' in item_cate:
                self.item_num[0] += 1
                self.item[0].append(item_id)
            elif 'top' in item_cate:
                self.item_num[1] += 1
                self.item[1].append(item_id)
            elif 'bottom' in item_cate:
                self.item_num[2] += 1
                self.item[2].append(item_id)
            elif 'suit' in item_cate:
                self.item_num[3] += 1
                self.item[3].append(item_id)

    def preference(self):
        g1 = tf.Graph()
        self.sess_preference = tf.Session(graph=g1)
        with self.sess_preference.as_default():
            with g1.as_default():
                self.preference = preference.TVBPR(K=64, K2=128, text_K=32)
                self.preference.attr_dict = text_dict
                self.preference.load_training_data(data_path+'/user_idx.json',data_path+'/item_idx.json')
                self.preference.train()

                saver_preference = tf.train.Saver()
                saver_preference.restore(self.sess_preference,
                                            tf.train.get_checkpoint_state('./preference/TVBPR/').model_checkpoint_path)
    def bodyshape(self):
        g2 = tf.Graph()
        self.sess_bodyshape = tf.Session(graph=g2)
        with self.sess_bodyshape.as_default():
            with g2.as_default():
                self.bodyshape = bodyshape.body_shape()
                self.bodyshape.train()

                saver_bodyshape = tf.train.Saver()
                saver_bodyshape.restore(self.sess_bodyshape,
                                            tf.train.get_checkpoint_state('./bodyshape/').model_checkpoint_path)

    def compatibility(self):
        g3 = tf.Graph()
        self.sess_compatibility = tf.Session(graph=g3)
        with self.sess_compatibility.as_default():
            with g3.as_default():
                self.compatibility = compatibility.lstm_vse()
                self.compatibility.batch_size = 1
                self.compatibility.train()

                saver_compatibility = tf.train.Saver()
                saver_compatibility.restore(self.sess_compatibility, tf.train.get_checkpoint_state('./compatibility/').model_checkpoint_path)


model = pcw_dc()
model.preference()
model.compatibility()
model.bodyshape()

for user in data:
    pcw_path = './result/%s/pcw/' % user
    if os.path.exists(pcw_path):
        continue
    else:
        model.user_id = user
        model.user_shape, _ = bsAssignment.get_bodyshape(data[user], size_dict)
        model.process_data(data[user])

        original_path = './result/%s/original/' % user
        if not os.path.exists(original_path):
            os.makedirs(original_path)
            for item_id in model.item[0] + model.item[1] + model.item[2] + model.item[3]:
                shutil.copy(img_path + '%s.jpg' % item_id, original_path)

        model.PCW_creation()
        os.makedirs(pcw_path)
        for item_id in model.item[0] + model.item[1] + model.item[2] + model.item[3]:
            shutil.copy(img_path + '%s.jpg' % item_id, pcw_path)
