import numpy as np

M=5  # measurements: [shoulder, bust, waist, waist, hip]
def drop_unnual_data(list):
    list = [x for x in list if x != 0]
    array=np.array(list)
    mean=np.mean(array)
    std=np.std(array)
    array2=[]
    for i in array:
        if abs(i-mean) <= 2*std:
            array2.append(i)
    return array2

def bodyshape_assignment(bu):
    bust = bu[1]
    waist = bu[3]
    hip = bu[4]
    if hip - bust <= 0.5:  # 0
        return 0, 'Strawberry Shape'
    elif hip - bust >= 4.5:  # 1
        return 1, 'Pear Shape'
    else:
        if bust - waist <= 6.5:  # 2
            return 2, 'Apple Shape'
        elif bust - waist >= 9.5:  # 3
            return 3, 'Hourglass Shape'
        else:
            return 4, 'Standard Shape'  # 4

def measurements_processing(user, size_dict):
    u_l = []
    for item in user:
        measurements = [0]*M
        if item['item_cate'] == 'shoes':
            continue
        elif item['item_size'] == '-':  ## One size
            continue
        elif item['item_size'] == 'free':  ## Free size
            continue
        else:
            if 'top' in item['item_cate']:
                measurements[0:3] = size_dict[item['item_size']][0:3]
                u_l.append(measurements)
            elif 'outer' in item['item_cate']:
                measurements[0:3] = size_dict[item['item_size']][0:3]
                u_l.append(measurements)
            elif 'bottom' in item['item_cate']:
                measurements[3:] = size_dict[item['item_size']][2:]
                u_l.append(measurements)
            elif 'suit' in item['item_cate']:
                measurements[0:3] = size_dict[item['item_size']][0:3]
                measurements[3:] = size_dict[item['item_size']][2:]
                u_l.append(measurements)
    u_l = np.array(u_l)
    bu = [0] * M
    for m_i in range(M):
        lm_i = drop_unnual_data(u_l[:,m_i])
        weight_i = [lm_i.count(i) for i in lm_i]
        bu[m_i] = np.average(lm_i, weights=weight_i)
    return bu


def get_bodyshape(user, size_dict):
    bu = measurements_processing(user, size_dict)
    return bodyshape_assignment(bu)



### example
# with open('./bodyFashion.json','r') as f:
#     data=json.load(f)
# with open('./size_dict.json','r') as f:
#     size_dict=json.load(f)
# user_id = 'U000000'
# idx, bs = get_bodyshape(data[user_id], size_dict)
# print('The body shape of %s is: %s'%(user_id, bs))
