## Code for ACM MM'19 paper "Personalized Capsule Wardrobe Creation with Garment and User Modeling". ##

## Required Packages ##
- Tensorflow-gpu 1.4.0
- Keras 2.1.5
- Numpy 1.17.0

## Personalized Capsule Wardrobe Creation ##
- Preparation
   - Download the bodyFashion dataset and put bodyFashion.json into /files/.
   - Build your own candidate set, where file "candidate.json" is needed to edit. 
      An example of the candidate set is already existed.

- PCWs Creation.
   - Perform pcw-dc.py. 
   - If you want to train them by yourself, please note the following points:
     1. Train the preference model to 0.91-0.92.
     2. Oversampling are used to deal with the data imbalance problem in body shape modeling.
