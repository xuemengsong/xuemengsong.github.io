# GP-BPR

Code for paper [GP-BPR: Personalized Compatibility Modeling for Clothing Matching](..)

## Dependencies

This project currently requires the stable version of [Pytorch](pytorch.org) 

- torch 1.0.0

or

- torch 1.0.1.post2

## Running command

python gpbpr.py